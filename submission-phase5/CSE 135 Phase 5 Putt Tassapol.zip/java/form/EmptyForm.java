package form;

import javax.servlet.http.*;
import org.apache.struts.action.*;

public class EmptyForm extends ActionForm {

}
