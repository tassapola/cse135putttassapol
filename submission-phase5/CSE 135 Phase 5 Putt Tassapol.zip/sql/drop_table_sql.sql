drop table if exists review_result;
drop table if exists user_roles;
drop table if exists users;
drop table if exists degree_holder;
drop table if exists degree;
drop table if exists applicant;
drop table if exists address;
drop table if exists specializations;
drop table if exists disciplines;
drop table if exists universities;
drop table if exists countries;
drop table if exists transcript;




