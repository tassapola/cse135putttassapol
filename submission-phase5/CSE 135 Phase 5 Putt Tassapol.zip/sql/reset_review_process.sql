update applicant set status=NULL;
DELETE FROM review_result;
