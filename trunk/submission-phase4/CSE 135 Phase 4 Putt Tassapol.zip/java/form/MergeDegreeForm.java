package form;

import javax.servlet.http.*;
import org.apache.struts.action.*;

public class MergeDegreeForm extends ActionForm {

	private String submit = null;

	public String getSubmit() {
		return submit;
	}

	public void setSubmit(String submit) {
		this.submit = submit;
	}

	
	
}
