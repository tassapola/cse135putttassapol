﻿insert into users (user_name, password, email) values ('yannis', md5('password'), 'admin@email.com');
insert into user_roles (user_name, role) values ('yannis', 'chair');
